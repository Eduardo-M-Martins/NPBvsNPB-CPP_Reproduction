#define CLASS 'B'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define COMPILETIME "28 Apr 2022"
#define LIBVER "201511"
#define CVER "9.4.0"
#define NPBVERSION "3.3.1"
#define CC "gcc -fopenmp"
#define CFLAGS "-O3 -fopenmp -mcmodel=medium"
#define CLINK "$(CC)"
#define CLINKFLAGS "-O3 -fopenmp -mcmodel=medium"
#define C_LIB "(none)"
#define C_INC "(none)"
